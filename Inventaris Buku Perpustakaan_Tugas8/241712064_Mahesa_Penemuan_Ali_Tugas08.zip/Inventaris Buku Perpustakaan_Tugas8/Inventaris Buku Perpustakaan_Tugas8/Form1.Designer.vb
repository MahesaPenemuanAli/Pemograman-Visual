Option Strict On

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    ' Membersihkan komponen ketika form ditutup.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then components.Dispose()
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    ' Membuat dan mengatur semua kontrol serta komponen melalui Designer.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
        lblJudulForm = New Label()
        lblPetunjuk = New Label()
        grpBuku = New GroupBox()
        lblKodeBuku = New Label()
        txtKodeBuku = New TextBox()
        lblJudul = New Label()
        txtJudul = New TextBox()
        lblPenulis = New Label()
        txtPenulis = New TextBox()
        lblKategori = New Label()
        cboKategori = New ComboBox()
        lblTahun = New Label()
        txtTahun = New TextBox()
        lblStok = New Label()
        txtStok = New TextBox()
        btnTambah = New Button()
        btnBersihkan = New Button()
        lblStatus = New Label()
        grpPencarian = New GroupBox()
        lblCari = New Label()
        txtCari = New TextBox()
        lblFilterKategori = New Label()
        cboFilterKategori = New ComboBox()
        lblUrut = New Label()
        cboUrut = New ComboBox()
        chkStokHabis = New CheckBox()
        dgvBuku = New DataGridView()
        bsBuku = New BindingSource(components)
        lblJumlah = New Label()
        lblTotalStok = New Label()
        errBuku = New ErrorProvider(components)
        grpBuku.SuspendLayout()
        grpPencarian.SuspendLayout()
        CType(dgvBuku, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(bsBuku, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(errBuku, System.ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        lblJudulForm.Name = "lblJudulForm"
        lblPetunjuk.Name = "lblPetunjuk"
        grpBuku.Name = "grpBuku"
        lblKodeBuku.Name = "lblKodeBuku"
        txtKodeBuku.Name = "txtKodeBuku"
        lblJudul.Name = "lblJudul"
        txtJudul.Name = "txtJudul"
        lblPenulis.Name = "lblPenulis"
        txtPenulis.Name = "txtPenulis"
        lblKategori.Name = "lblKategori"
        cboKategori.Name = "cboKategori"
        lblTahun.Name = "lblTahun"
        txtTahun.Name = "txtTahun"
        lblStok.Name = "lblStok"
        txtStok.Name = "txtStok"
        btnTambah.Name = "btnTambah"
        btnBersihkan.Name = "btnBersihkan"
        lblStatus.Name = "lblStatus"
        grpPencarian.Name = "grpPencarian"
        lblCari.Name = "lblCari"
        txtCari.Name = "txtCari"
        lblFilterKategori.Name = "lblFilterKategori"
        cboFilterKategori.Name = "cboFilterKategori"
        lblUrut.Name = "lblUrut"
        cboUrut.Name = "cboUrut"
        chkStokHabis.Name = "chkStokHabis"
        dgvBuku.Name = "dgvBuku"
        lblJumlah.Name = "lblJumlah"
        lblTotalStok.Name = "lblTotalStok"
        lblJudulForm.Location = New Point(24, 10)
        lblJudulForm.Size = New Size(800, 38)
        lblPetunjuk.Location = New Point(26, 50)
        lblPetunjuk.Size = New Size(900, 20)
        grpBuku.Location = New Point(24, 76)
        grpBuku.Size = New Size(1032, 170)
        lblKodeBuku.Location = New Point(18, 20)
        lblKodeBuku.Size = New Size(300, 18)
        txtKodeBuku.Location = New Point(18, 40)
        txtKodeBuku.Size = New Size(300, 23)
        lblJudul.Location = New Point(350, 20)
        lblJudul.Size = New Size(300, 18)
        txtJudul.Location = New Point(350, 40)
        txtJudul.Size = New Size(300, 23)
        lblPenulis.Location = New Point(682, 20)
        lblPenulis.Size = New Size(300, 18)
        txtPenulis.Location = New Point(682, 40)
        txtPenulis.Size = New Size(300, 23)
        lblKategori.Location = New Point(18, 73)
        lblKategori.Size = New Size(300, 18)
        cboKategori.Location = New Point(18, 93)
        cboKategori.Size = New Size(300, 23)
        lblTahun.Location = New Point(350, 73)
        lblTahun.Size = New Size(300, 18)
        txtTahun.Location = New Point(350, 93)
        txtTahun.Size = New Size(300, 23)
        lblStok.Location = New Point(682, 73)
        lblStok.Size = New Size(300, 18)
        txtStok.Location = New Point(682, 93)
        txtStok.Size = New Size(300, 23)
        btnTambah.Location = New Point(18, 128)
        btnTambah.Size = New Size(132, 33)
        btnBersihkan.Location = New Point(160, 128)
        btnBersihkan.Size = New Size(120, 33)
        lblStatus.Location = New Point(300, 128)
        lblStatus.Size = New Size(700, 36)
        grpPencarian.Location = New Point(24, 258)
        grpPencarian.Size = New Size(1032, 78)
        lblCari.Location = New Point(18, 24)
        lblCari.Size = New Size(330, 18)
        txtCari.Location = New Point(18, 46)
        txtCari.Size = New Size(330, 23)
        lblFilterKategori.Location = New Point(370, 24)
        lblFilterKategori.Size = New Size(180, 18)
        cboFilterKategori.Location = New Point(370, 46)
        cboFilterKategori.Size = New Size(180, 23)
        lblUrut.Location = New Point(574, 24)
        lblUrut.Size = New Size(220, 18)
        cboUrut.Location = New Point(574, 46)
        cboUrut.Size = New Size(220, 23)
        chkStokHabis.Location = New Point(820, 48)
        chkStokHabis.Size = New Size(180, 23)
        dgvBuku.Location = New Point(24, 348)
        dgvBuku.Size = New Size(1032, 210)
        lblJumlah.Location = New Point(24, 576)
        lblJumlah.Size = New Size(500, 24)
        lblTotalStok.Location = New Point(686, 576)
        lblTotalStok.Size = New Size(370, 24)
        lblJudulForm.Text = "Inventaris Buku Perpustakaan"
        lblJudulForm.Font = New Font("Segoe UI", 19.0!, FontStyle.Bold)
        lblJudulForm.ForeColor = Color.FromArgb(30, 64, 90)
        lblPetunjuk.Text = "Tambahkan buku, cari koleksi, dan lihat jumlah stok yang tersedia."
        lblPetunjuk.ForeColor = Color.DimGray
        grpBuku.Text = "Data buku baru"
        grpBuku.TabIndex = 0
        grpBuku.TabStop = False
        lblKodeBuku.Text = "Kode buku (BK + 4 digit)"
        txtKodeBuku.CharacterCasing = CharacterCasing.Upper
        txtKodeBuku.TabIndex = 0
        lblJudul.Text = "Judul buku"
        txtJudul.TabIndex = 1
        lblPenulis.Text = "Penulis"
        txtPenulis.TabIndex = 2
        lblKategori.Text = "Kategori"
        cboKategori.DropDownStyle = ComboBoxStyle.DropDownList
        cboKategori.Items.AddRange(New Object() {"Fiksi", "Nonfiksi", "Referensi", "Majalah"})
        cboKategori.TabIndex = 3
        lblTahun.Text = "Tahun terbit"
        txtTahun.TabIndex = 4
        lblStok.Text = "Jumlah stok (eksemplar)"
        txtStok.TabIndex = 5
        btnTambah.Text = "Tambah Buku"
        btnTambah.TabIndex = 6
        btnTambah.BackColor = Color.FromArgb(30, 80, 115)
        btnTambah.ForeColor = Color.White
        btnTambah.FlatStyle = FlatStyle.Flat
        btnTambah.UseVisualStyleBackColor = False
        btnBersihkan.Text = "Bersihkan Isian"
        btnBersihkan.TabIndex = 7
        btnBersihkan.CausesValidation = False
        btnBersihkan.UseVisualStyleBackColor = True
        lblStatus.Text = "Lengkapi semua isian, lalu klik Tambah Buku."
        lblStatus.TextAlign = ContentAlignment.MiddleLeft
        lblStatus.ForeColor = Color.FromArgb(65, 80, 90)
        grpPencarian.Text = "Pencarian dan tampilan"
        grpPencarian.TabIndex = 1
        grpPencarian.TabStop = False
        lblCari.Text = "Cari judul atau penulis"
        txtCari.TabIndex = 0
        lblFilterKategori.Text = "Filter kategori"
        cboFilterKategori.DropDownStyle = ComboBoxStyle.DropDownList
        cboFilterKategori.Items.AddRange(New Object() {"Semua", "Fiksi", "Nonfiksi", "Referensi", "Majalah"})
        cboFilterKategori.TabIndex = 1
        cboFilterKategori.SelectedIndex = 0
        lblUrut.Text = "Urutkan buku"
        cboUrut.DropDownStyle = ComboBoxStyle.DropDownList
        cboUrut.Items.AddRange(New Object() {"Urutan awal", "Judul A-Z", "Tahun terbaru", "Stok terbanyak"})
        cboUrut.TabIndex = 2
        cboUrut.SelectedIndex = 0
        chkStokHabis.Text = "Hanya stok habis"
        chkStokHabis.TabIndex = 3
        chkStokHabis.UseVisualStyleBackColor = True
        dgvBuku.AllowUserToAddRows = False
        dgvBuku.AllowUserToDeleteRows = False
        dgvBuku.AllowUserToResizeRows = False
        dgvBuku.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        dgvBuku.BackgroundColor = Color.White
        dgvBuku.BorderStyle = BorderStyle.FixedSingle
        dgvBuku.ColumnHeadersHeight = 28
        dgvBuku.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        dgvBuku.MultiSelect = False
        dgvBuku.ReadOnly = True
        dgvBuku.RowHeadersVisible = False
        dgvBuku.RowTemplate.Height = 22
        dgvBuku.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvBuku.TabIndex = 2
        lblJumlah.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left
        lblJumlah.Font = New Font("Segoe UI", 10.0!, FontStyle.Bold)
        lblJumlah.ForeColor = Color.FromArgb(30, 64, 90)
        lblJumlah.Text = "Menampilkan 0 dari 0 buku"
        lblTotalStok.Anchor = AnchorStyles.Bottom Or AnchorStyles.Right
        lblTotalStok.Font = New Font("Segoe UI", 10.0!, FontStyle.Bold)
        lblTotalStok.ForeColor = Color.FromArgb(30, 64, 90)
        lblTotalStok.Text = "Total stok: 0 eksemplar"
        lblTotalStok.TextAlign = ContentAlignment.TopRight
        errBuku.BlinkStyle = ErrorBlinkStyle.NeverBlink
        errBuku.ContainerControl = Me
        grpBuku.Controls.Add(lblKodeBuku)
        grpBuku.Controls.Add(txtKodeBuku)
        grpBuku.Controls.Add(lblJudul)
        grpBuku.Controls.Add(txtJudul)
        grpBuku.Controls.Add(lblPenulis)
        grpBuku.Controls.Add(txtPenulis)
        grpBuku.Controls.Add(lblKategori)
        grpBuku.Controls.Add(cboKategori)
        grpBuku.Controls.Add(lblTahun)
        grpBuku.Controls.Add(txtTahun)
        grpBuku.Controls.Add(lblStok)
        grpBuku.Controls.Add(txtStok)
        grpBuku.Controls.Add(btnTambah)
        grpBuku.Controls.Add(btnBersihkan)
        grpBuku.Controls.Add(lblStatus)
        grpPencarian.Controls.Add(lblCari)
        grpPencarian.Controls.Add(txtCari)
        grpPencarian.Controls.Add(lblFilterKategori)
        grpPencarian.Controls.Add(cboFilterKategori)
        grpPencarian.Controls.Add(lblUrut)
        grpPencarian.Controls.Add(cboUrut)
        grpPencarian.Controls.Add(chkStokHabis)
        Controls.Add(lblJudulForm)
        Controls.Add(lblPetunjuk)
        Controls.Add(grpBuku)
        Controls.Add(grpPencarian)
        Controls.Add(dgvBuku)
        Controls.Add(lblJumlah)
        Controls.Add(lblTotalStok)
        AutoScaleDimensions = New SizeF(7.0!, 15.0!)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(247, 249, 251)
        ClientSize = New Size(1080, 608)
        MinimumSize = New Size(1096, 647)
        Name = "Form1"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Inventaris Buku Perpustakaan - Tugas 08"
        grpBuku.ResumeLayout(False)
        grpPencarian.ResumeLayout(False)
        CType(dgvBuku, System.ComponentModel.ISupportInitialize).EndInit()
        CType(bsBuku, System.ComponentModel.ISupportInitialize).EndInit()
        CType(errBuku, System.ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub
    Friend WithEvents lblJudulForm As Label
    Friend WithEvents lblPetunjuk As Label
    Friend WithEvents grpBuku As GroupBox
    Friend WithEvents lblKodeBuku As Label
    Friend WithEvents txtKodeBuku As TextBox
    Friend WithEvents lblJudul As Label
    Friend WithEvents txtJudul As TextBox
    Friend WithEvents lblPenulis As Label
    Friend WithEvents txtPenulis As TextBox
    Friend WithEvents lblKategori As Label
    Friend WithEvents cboKategori As ComboBox
    Friend WithEvents lblTahun As Label
    Friend WithEvents txtTahun As TextBox
    Friend WithEvents lblStok As Label
    Friend WithEvents txtStok As TextBox
    Friend WithEvents btnTambah As Button
    Friend WithEvents btnBersihkan As Button
    Friend WithEvents lblStatus As Label
    Friend WithEvents grpPencarian As GroupBox
    Friend WithEvents lblCari As Label
    Friend WithEvents txtCari As TextBox
    Friend WithEvents lblFilterKategori As Label
    Friend WithEvents cboFilterKategori As ComboBox
    Friend WithEvents lblUrut As Label
    Friend WithEvents cboUrut As ComboBox
    Friend WithEvents chkStokHabis As CheckBox
    Friend WithEvents dgvBuku As DataGridView
    Friend WithEvents bsBuku As BindingSource
    Friend WithEvents lblJumlah As Label
    Friend WithEvents lblTotalStok As Label
    Friend WithEvents errBuku As ErrorProvider
End Class


